sudo cp paxx /usr/local/bin/
